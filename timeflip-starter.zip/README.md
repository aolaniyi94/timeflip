# TimeFlip Starter

This is a simple starter project for TimeFlip.live — a time zone converter website.

- Homepage: `/`
- EST to IST converter: `/est-to-ist`

To deploy, drag and drop this folder into Vercel.