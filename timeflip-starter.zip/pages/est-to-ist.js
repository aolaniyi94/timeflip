export default function EstToIst() {
  const estTime = new Date();
  const istOffset = 5.5 * 60; // IST is UTC +5:30
  const estOffset = -4 * 60;  // EST is UTC -4 (adjust for daylight saving if needed)
  const timeDiff = istOffset - estOffset;
  const istTime = new Date(estTime.getTime() + timeDiff * 60000);

  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>EST to IST Time Converter</h1>
      <p>Current EST time: {estTime.toLocaleTimeString('en-US', { timeZone: 'America/New_York' })}</p>
      <p>Current IST time: {istTime.toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>
      <a href="/">← Back to Home</a>
    </div>
  );
}