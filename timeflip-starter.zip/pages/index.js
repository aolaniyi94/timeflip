export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      <h1>Welcome to TimeFlip.live</h1>
      <p>This is your simple time zone converter website.</p>
      <a href="/est-to-ist">Go to EST to IST Converter</a>
    </div>
  );
}